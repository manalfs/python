from pathlib import Path

originPath = Path('.')
histosPath = Path(originPath / 'histogrammes')
photosPath = Path(originPath / 'photos')
scriptsPath = Path(originPath / 'scripts')
sobelPath = Path(originPath / 'sobel')
csvPath = Path(originPath / 'csv')